package entidades;

import java.util.Scanner;

public interface Favorito {
    Scanner read = new Scanner(System.in);
void crear();
}
